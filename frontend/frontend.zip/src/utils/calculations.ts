import type { InvoiceData } from "./types"

export function calculateTotals(invoiceData: InvoiceData): InvoiceData {
  const subtotal = invoiceData.items.reduce((sum, item) => sum + item.subtotal, 0)
  const total = subtotal + invoiceData.otrosTributos
  return { ...invoiceData, subtotal, total }
}
