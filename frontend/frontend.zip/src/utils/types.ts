export interface Cliente {
  id: string
  nombre: string
  telefono: string
  direccion: string
  documento?: string
}

export interface InvoiceItem {
  id: string
  codigo: string
  descripcion: string
  cantidad: number
  unidadMedida: string
  precioUnitario: number
  bonificacion: number
  importeBonif: number
  subtotal: number
  esServicio: boolean
  esTemporal: boolean
}

export interface InvoiceData {
  emisorNombre: string
  emisorTelefono: string
  emisorDireccion: string
  clienteNombre: string
  clienteTelefono: string
  clienteDireccion: string
  clienteDocumento: string
  fechaEmision: string
  periodoDesde: string
  periodoHasta: string
  fechaVencimiento: string
  condicionVenta: string
  numeroComprobante: string
  items: InvoiceItem[]
  subtotal: number
  otrosTributos: number
  total: number
  cae: string
  fechaVencimientoCae: string
  certificacion: string
}

export type ClienteView = "buttons" | "alta" | "buscar"
