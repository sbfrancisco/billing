import type { Cliente } from "./types"
import { getUserFromLocalStorage } from "./userStorage"

export async function fetchClientes(): Promise<Cliente[]> {
  const client = getUserFromLocalStorage()

  try {
    const response = await fetch("http://localhost:8000/clients?id=" + client.documento)
    if (!response.ok) {
      throw new Error("Error al cargar clientes")
    }
    return await response.json()
  } catch (error) {
    console.error("Error al cargar clientes:", error)
    throw error
  }
}

export async function saveCliente(clienteData: Omit<Cliente, "id">): Promise<void> {
  const client = getUserFromLocalStorage()

  try {
    const response = await fetch("http://localhost:8000/save_client", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        ...clienteData,
        emisor: client.documento,
      }),
    })

    const data = await response.json()
    if (!response.ok) {
      throw new Error(data.message || "Error al guardar el cliente")
    }
  } catch (error) {
    console.error("Error al guardar cliente:", error)
    throw error
  }
}
