"use client"

import { FileText, Save } from "lucide-react"
import { InvoiceView } from "@/components/InvoiceView"
import { ClientSection } from "@/components/ClientSection"
import { ItemsSection } from "../components/ItemsSections"
import { TotalsSection } from "../components/TotalSections"
import { useInvoiceView } from "../../hooks/use-invoice-view"

export default function GeneratePage() {
  const {
    clientes,
    clienteView,
    setClienteView,
    nuevoClienteData,
    setNuevoClienteData,
    invoiceData,
    showForm,
    setShowForm,
    invoiceGenerated,
    setInvoiceGenerated,
    handleSeleccionCliente,
    handleGuardarNuevoCliente,
    addItem,
    removeItem,
    updateItem,
  } = useInvoiceView()

  if (!showForm) {
    return (
      <InvoiceView
        invoiceData={invoiceData}
        invoiceGenerated={invoiceGenerated}
        onEdit={() => setShowForm(true)}
        onSave={() => {
          console.log("Guardando factura en base de datos:", invoiceData)
          alert("Factura guardada en la base de datos correctamente")
          setInvoiceGenerated(false)
        }}
      />
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-6xl mx-auto px-4">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Generador de Facturas</h1>
          <p className="text-gray-600 mt-2">Crea y gestiona tus facturas de manera profesional</p>
        </div>

        <div className="space-y-6">
          {/* Client Section */}
          <ClientSection
            clientes={clientes}
            clienteView={clienteView}
            setClienteView={setClienteView}
            nuevoClienteData={nuevoClienteData}
            setNuevoClienteData={setNuevoClienteData}
            invoiceData={invoiceData}
            onSeleccionCliente={handleSeleccionCliente}
            onGuardarNuevoCliente={handleGuardarNuevoCliente}
          />

          {/* Items Section */}
          <ItemsSection
            items={invoiceData.items}
            onAddItem={addItem}
            onRemoveItem={removeItem}
            onUpdateItem={updateItem}
          />

          {/* Totals */}
          {invoiceData.items.length > 0 && (
            <TotalsSection
              subtotal={invoiceData.subtotal}
              otrosTributos={invoiceData.otrosTributos}
              total={invoiceData.total}
            />
          )}

          {/* Final Actions */}
          <div className="bg-white rounded-lg shadow-sm border">
            <div className="p-6">
              <div className="flex flex-col sm:flex-row justify-center gap-4">
                {invoiceGenerated && (
                  <button
                    className="px-6 py-3 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors font-medium flex items-center gap-2"
                    onClick={() => {
                      console.log("Guardando factura:", invoiceData)
                      alert("Factura guardada correctamente")
                    }}
                  >
                    <Save className="w-4 h-4" />
                    Guardar Factura
                  </button>
                )}
                <button
                  className="px-6 py-3 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors font-medium flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                  onClick={() => {
                    setShowForm(false)
                    setInvoiceGenerated(true)
                  }}
                  disabled={!invoiceData.clienteNombre || invoiceData.items.length === 0}
                >
                  <FileText className="w-4 h-4" />
                  Ver Factura
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
